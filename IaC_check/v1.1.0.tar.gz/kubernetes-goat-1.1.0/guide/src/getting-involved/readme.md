# Getting Involved

First of all, thank you so much for showing interest in [Kubernetes Goat](https://github.com/madhuakula/kubernetes-goat), we really appreciate it.

Here are some of the ways you can contribute to the Kubernetes-Goat

* By providing your valuable feedback. Your honest feedback is always appreciated, no matter if it is positive or negative :)

* By contributing to the development of platform and scenarios

* Improving the documentation/notes

* By spreading the word and sharing with community, friends, and colleagues

## Follow in Social Media

* [Github](https://github.com/madhuakula/kubernetes-goat)
* [Twitter](https://twitter.com/madhuakula)
