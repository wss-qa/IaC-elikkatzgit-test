# KICS report for Kubernetes Goat


[KICS](https://kics.io) by Checkmarx identifed 236 issues in Kubernetes and Docker configuration issues in Kubernetes Goat


[Check the detailed report here](kics-output.html)

