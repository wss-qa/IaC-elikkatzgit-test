# Sysdig Falco - Runtime Security Monitoring & Detection

## Scenario Information

This scenario is deploy runtime security monitoring & detection for containers and kubernetes resources.

* To get started with this scenario you can deploy the below helm chart with version 3

```bash
helm repo add falcosecurity https://falcosecurity.github.io/charts
helm repo update
helm install falco falcosecurity/falco
```

![Scenario 18 helm falco setup](images/sc-18-1.png)

## Scenario Solution

> `Falco`, the cloud-native runtime security project, is the de facto Kubernetes threat detection engine. Falco was created by Sysdig in 2016 and is the first runtime security project to join CNCF as an incubation-level project. Falco detects unexpected application behavior and alerts on threats at runtime.

Falco uses system calls to secure and monitor a system, by:

* Parsing the Linux system calls from the kernel at runtime
* Asserting the stream against a powerful rules engine
* Alerting when a rule is violated

Falco ships with a default set of rules that check the kernel for unusual behavior such as:

* Privilege escalation using privileged containers
* Namespace changes using tools like `setns`
* Read/Writes to well-known directories such as /etc, /usr/bin, /usr/sbin, etc
* Creating symlinks
* Ownership and Mode changes
* Unexpected network connections or socket mutations
* Spawned processes using execve
* Executing shell binaries such as sh, bash, csh, zsh, etc
* Executing SSH binaries such as ssh, scp, sftp, etc
* Mutating Linux coreutils executables
* Mutating login binaries
* Mutating shadowutil or passwd executables such as shadowconfig, pwck, chpasswd, getpasswd, change, useradd, etc, and others.

* Get more details about the falco deployment

```bash
kubectl get pods --selector app=falco
```

![Scenario 18 falco get pods](images/sc-18-2.png)

* Manually obtaining the logs from the falco systems

```bash
kubectl logs -f -l app=falco
```

* Now, let's spin up a hacker container and read senstive file and see if that detects by Falco

```bash
kubectl run --rm --restart=Never -it --image=madhuakula/hacker-container -- bash
```

* Read the sensitive file

```bash
cat /etc/shadow
```

![Scenario 18 falco detect /etc/shadow](images/sc-18-3.png)

## Miscellaneous

* [https://falco.org/](https://falco.org/)
