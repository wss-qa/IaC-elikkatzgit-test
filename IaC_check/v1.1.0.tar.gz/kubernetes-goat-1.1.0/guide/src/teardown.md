# Teardown Kubernetes Goat

* Teardown the entire Kubernetes Goat infrastructure

```bash
bash teardown-kubernetes-goat.sh
```

> Note: Ensure clean up what you installed and used, It's better to delete the cluster.
