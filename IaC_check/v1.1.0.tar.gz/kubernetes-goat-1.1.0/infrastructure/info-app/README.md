# Info App

This docker container is part of Kubernetes Goat.

## Building this docker container

```bash
docker build -t madhuakula/k8s-goat-info-app .
```

## Push this docker container to Docker Hub

```bash
docker push madhuakula/k8s-goat-info-app
```
